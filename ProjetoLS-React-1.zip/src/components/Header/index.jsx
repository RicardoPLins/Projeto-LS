import React from 'react';
import './style.css';

const Header = () => {
  return (
    <div className="container-header">
      <h1>Escolha a plataforma</h1>
      <div className="sidebar">
        <div className="sidebar-item">PS4</div>
        <div className="sidebar-item">PS5</div>
        <div className="sidebar-item">XONE</div>
        <div className="sidebar-item">XSEIES</div>
        <div className="sidebar-item">PC</div>
      </div>
    </div>
  );
}
 
export default Header;