import React, { useState, useEffect } from 'react';
import './style.css';
import Card from '../Card';

const Body = () => {
  const [data, setData] = useState([]);
  const [addData, setAddData] = useState([]);
  const [displayModal, setDisplayModal] = useState('none');
  const [description, setDescription] = useState('');
  const [value, setValue] = useState('');


  function handleDisplayModal(){
    displayModal === 'none' ? setDisplayModal('flex') : setDisplayModal('none');
    setDescription('');
    setValue('');
  }

  // Por fins demonstrativos optamos por inserir um novo array de objetos pois não conseguimos fazer escritas no arquivo JSON
  function addCard(description, value){
    const sValue = value.split('R$ ');
    const reg = /K/g;
    //console.log(reg.test(description));
    //console.log(sValue.length);
    if(sValue.length <= 1 || reg.test(description) === false){
      alert('Ocrreu um erro nos dados inseridos.\n\n- Insira um K depois da descrição\n- Insira o R$ e um espaço antes do valor');
    }
    else {
      addData.push({ coins: description, valor: value });
      handleDisplayModal();
    }
  }

  useEffect(() => {
    fetch('./dataset.json', {
      headers: {
        Accept: "application/json"
      }
    }).then(res => res.json()).then(res => setData(res.data));
  }, []);

  const resultCard = data.map(value => {
    return(
      <Card
        key={ value.id }
        description={ value.coins }
        value={ value.valor }
      />
    );
  });

  const resultAddCard = addData.map((value, index) => {
    return(
      <Card
        key={ index + 1 }
        description={ value.coins }
        value={ value.valor }
      />
    );
  });

  return (
    <div className="container-body">
      <div className="container-add">
        <button onClick={ handleDisplayModal } class="btn-add">
          +
        </button>
        <div
          className="modal"
          style={{
            display: displayModal
          }}
        >
          <div className="modal-top">
            <p>Cadastrar</p>
          </div>
          <div className="modal-mid">
            <p>Coin</p>
            <input
              class="modal-input"
              type="text"
              value={ description }
              onChange={ (value) => { setDescription(value.target.value) }}
            />
            <p>Valor</p>
            <input
              value={ value }
              onChange={ (value) => { setValue(value.target.value) }}
              class="modal-input"
              type="text"/>
          </div>
          <div className="modal-bottom">
            <div className="btn-container">
              <button onClick={ handleDisplayModal } class="modal-btn-close">
                <p>Fechar</p>
              </button>
              <button onClick={ () => { addCard(description, value) } } class="modal-btn-save">
                <p>Salvar</p>
              </button>
            </div>
          </div>
        </div>
      </div>
      { resultCard }
      { resultAddCard }
    </div>
  );
}
 
export default Body;