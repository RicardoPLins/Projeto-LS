import react from 'react';
import './style.css';
import image from '../../assets/fifa-coins.jpg';

const Card = ({ description, value }) => {
  return (
    <div className="container">
      <img src={ image } alt="imagem" />
      <p class="description">{ description }</p>
      <p class="value">{ value }</p>
      <button class="btn-send">
        <p>Comprar</p>
      </button>
    </div>
  );
}
 
export default Card;